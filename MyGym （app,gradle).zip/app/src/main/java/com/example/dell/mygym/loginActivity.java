package com.example.dell.mygym;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
public class loginActivity extends AppCompatActivity {

    private Button bt;
    private Button lrg;
    EditText username, password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bmob.initialize(this, "d35fe3de7bf3fd8716c88e949e59dc97");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        bt=(Button) findViewById(R.id.log);
        username= (EditText)findViewById(R.id.usname);
        password = (EditText)findViewById(R.id.pass);
        bt.setOnClickListener(new OnClickListener(){
            @Override
            public  void onClick(View v) {
                if (checkEdit()) {
                    if (username.getText().toString().equals("")) {
                        Toast.makeText(loginActivity.this, "请输入账号", Toast.LENGTH_SHORT).show();
                    } else {
                        BmobUser user = new BmobUser();
                        user.setUsername(username.getText().toString());
                        user.setPassword(password.getText().toString());
                        user.login(new SaveListener<BmobUser>() {
                            @Override
                            public void done(BmobUser bmobUser, BmobException e) {
                                if (e == null) {
                                    Toast.makeText(loginActivity.this, bmobUser.getUsername() + "登录成功", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(loginActivity.this, MainActivity.class);
                                    startActivity(intent);
                                } else {
                                   // Log.e("登录失败", "原因: ", e);
                                    Toast.makeText(loginActivity.this,"登录失败,原因："+e,Toast.LENGTH_SHORT).show();
                                }
                            }

                        });
                    }
                }
            }
        });
        lrg=(Button)findViewById(R.id.regl);
        lrg.setOnClickListener(new OnClickListener(){
            @Override
            public  void onClick(View v2){
                Intent intent=new Intent(loginActivity.this,regActivity.class);
                startActivity(intent);
            }
        });

    }
    //检查注册信息
    public boolean checkEdit(){
        if(username.getText().toString().equals("")){
            Toast.makeText(loginActivity.this, "账户不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(password.getText().toString().equals("")){
            Toast.makeText(loginActivity.this, "密码不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
